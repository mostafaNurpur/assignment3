<?php

$con = mysqli_connect("localhost" , "mostafa", "09374689418" ,"ControlSystemsWorkers") or die("Connection Failed");
mysqli_set_charset($con,"utf8");

?>
