<?php   session_start();
include("db.php");

$query = "SELECT * FROM  `control`";
$run = mysqli_query($con , $query);
if(isset($_POST) & !empty($_POST)){

        $enter_time    = $_POST['enter_time'];
        $out_time      = $_POST['out_time'];
        $morakhasi     = $_POST['morakhasi'];
        $name          = $_SESSION['name'];
        $family        = $_SESSION['family'];
        $lunch         = $_POST['lunch'];

        $sql = "INSERT INTO `tbl_check` (name , family , enterd_time , out_time , morakhasi , lunch) VALUES ('$name' , '$family' , '$enter_time' , '$out_time' , '$morakhasi' , '$lunch')";

        $result = mysqli_query($con, $sql);
        if ($result){
            $smsg =("اطلاعات با موفقیت ثبت شد");

        }else{
            $fmsg =("ثبت اطلاعات با مشکل مواجه شده است");

        }


}
?>
<html>
<head>
    <title>Control System workers</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</head>
<body>

<?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert" > <?php echo $smsg; ?> </div>
<?php } ?>
<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div>
<?php } ?>

<?php
$name = $_SESSION['name'];
$query="SELECT * FROM `control` WHERE name = '$name' ";
$result=mysqli_query($con,$query);
$tas = mysqli_fetch_assoc($result);
?>
<h2 style="color: white; font-size: 20px; text-align: center ; margin: 2%"><?php echo   $tas["name"]." ".$tas["family"] . "  " ."welcome"?></h2>
<?php

?>

<h3>Control System tables</h3>
<div class="tbl-header">
    <table cellpadding="0" cellspacing="0" border="0" class="table-fill">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>family</th>
            <th>enter time</th>
            <th>out time</th>
            <th>morakhasi</th>
            <th>lunch</th>
        </tr>
        </thead>
    </table>
</div>
<form method="post">
    <div class="tbl-content">
        <table cellpadding="0" cellspacing="0" border="0">
            <tbody>
            <?php
            while ($row = mysqli_fetch_array($run))
            {
            ?>
            <div>
                <tr>
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?> </td>
                    <td><?php echo $row['family'] ?></td>
                    <td><input type="time" id="time" name="enter_time" ></td>
                    <td><input type="time" id="time" name="out_time" ></td>
                    <td><input type="text" name="morakhasi" style="width: 100% ; padding: 18px"></td>
                    <td><select name="lunch" id="sel">
                            <option>قرمه سبزی</option>
                            <option>چلو کباب</option>
                            <option>استانبولی</option>
                            <option>جوجه کباب</option>
                            <option>قیمه</option>
                        </select>
                    </td>
                    <?php }
                    ?>
                </tr>
                    <td>
                        <button class="button" id="sub" name="submit" style="width: 99% ; ">
                            <div class="submit"><h3>Submit</h3></div>
                            <div class="arrow">
                                <div class="top line"></div>
                                <div class="bottom line"></div>
                            </div>
                        </button>
                    </td>
            </div>
            </tbody>

        </table>
    </div>
</form>

</body>
</html>



<style>
    h3{
        font-size: 18px;
        color: #fff;
        text-transform: uppercase;
        font-weight: 300;
        text-align: center;
        margin-bottom: 15px;
    }
    table{
        width:96%;
        table-layout: fixed;
    }
    .tbl-header{
        width:96%;
    }
    .tbl-content{
        overflow-x:auto;
    }
    body{
        margin-left: 50px;
        margin-top: 3%;
        background: -webkit-linear-gradient(left,#4d4d4d, #4d4d4d);
        font-family: 'Roboto', sans-serif;
    }
    ::-webkit-scrollbar {
        width: 6px;
    }
    ::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    }
    ::-webkit-scrollbar-thumb {
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    }
    .table-fill {
        width:100%;
        position: relative;
        background: white;
        border-radius:20px;
        border-collapse: collapse;
        margin: auto;
        font-size: 10px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }
    th {
        color:#D5DDE5;
        background:#36304a;
        border-bottom:4px solid #9ea7af;
        border-right: 1px solid #343a45;
        font-size:20px;
        font-weight: 50;
        padding:15;
        text-align:center;
        text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
        vertical-align:middle;
    }

    th:first-child {
        border-top-left-radius:3px;
    }

    th:last-child {
        border-top-right-radius:3px;
        border-right:none;
    }

    tr {
        border-top: 1px solid #C1C3D1;
        color:#666B85;
        font-size:8px;
        font-weight:normal;
        text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
    }

    tr:hover td {
        background:#4E5066;
        color:#FFFFFF;
        border-top: 1px solid #22262e;
    }

    tr:first-child {
        border-top:none;
    }

    tr:last-child {
        border-bottom:none;
    }

    tr:nth-child(odd) td {
        background:#EBEBEB;
    }

    tr:nth-child(odd):hover td {
        background:#4E5066;
    }

    tr:last-child td:first-child {
        border-bottom-left-radius:3px;
    }

    tr:last-child td:last-child {
        border-bottom-right-radius:3px;
    }

    td {
        background:#FFFFFF;
        text-align:center;
        vertical-align:middle;
        font-weight:300;
        font-size:16px;
        text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
        border-right: 1px solid #C1C3D1;
    }

    td:last-child {
        border-right: 0;
    }

    /*progress bar*/

    #sub{
        color: #fff;
        font-family: Raleway, Helvetica, sans-serif;
        font-size: 0.5rem;
        font-weight: 100;
    }

    .button {
        position: relative;
        height: 60px;
        width: 200px;
        background: #00BCD4;
        text-align: center;
        cursor: pointer;
        overflow: hidden;
        -webkit-transition: all 0.3s ease;
        -moz-transition: all 0.3s ease;
        transition: all 0.3s ease;
    }

    .submit,
    .arrow {
        display: inline-block;
        -webkit-transition: all 0.2s ease;
        -moz-transition: all 0.2s ease;
        transition: all 0.2s ease;
    }

    .submit {
        text-transform: uppercase;
        margin: 14px 0 0 26px;
    }

    .arrow {
        position: relative;
        top: -3px;
        opacity: 0;
    }

    .line {
        height: 3px;
        width: 20px;
        background: #fff;
    }

    .top {
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .bottom {
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        transform: rotate(-45deg);
        margin-top: 10px;
    }

    .button:active {
        -webkit-transform: scale(1.3);
        -moz-transform: scale(1.3);
        transform: scale(1.3);
    }

    .button.hover .submit {
        -webkit-transform: translateX(-90px);
        -moz-transform: translateX(-90px);
        transform: translateX(-90px);
        opacity: 0;
    }

    .button.hover .arrow {

        -webkit-transform: translateX(-70px);
        -moz-transform: translateX(-70px);
        transform: translateX(-70px);
        opacity: 1;
    }

    .button.active .arrow {
        padding-left: 25px;
        opacity: 1;
        -webkit-transform: rotate(90deg) translateY(50px);
        -moz-transform: rotate(90deg) translateY(50px);
        transform: rotate(90deg) translateY(50px);
    }

    .button.active {
        background: #4CAF50;
    }

    .button.active .submit {
        opacity: 0;
    }

    .button.active .top {
        width: 34px;
    }

    .button.active .bottom {
        margin: 14px 0 0 12px;
    }

    #time{
        width: 99%;
        padding: 12px;
        text-align: center;
        font-size: 20px;
    }
    .alert-success , .alert-danger{
        width: 20%;
        text-align: center;
        margin-left: 40%;
    }

    #sel{
        width: 99%;
        padding: 15px;
        font-size: 20px;
        font-family: IRANSans;
    }
</style>

<script>

    /*progress bar*/
    function hover() {
        $(".button").on("mouseenter", function() {
            return $(this).addClass("hover");
        });
    }

    function hoverOff() {
        $(".button").on("mouseleave", function() {
            return $(this).removeClass("hover");
        });
    }

    function active() {
        $(".button").on("click", function() {
            return $(this).addClass("active");
        });
    }
    hover();
    hoverOff();
    active();

</script>