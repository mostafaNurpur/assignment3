import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import java.io.IOException;

import static java.lang.System.exit;

public class main
{
	private static String username ;
	private static String password ;
	public static void main(String[] args) throws IOException {
		morakhasi mo = new morakhasi();
		Date d = new Date();
		Scanner sc = new Scanner(System.in);
		Scanner s = new Scanner(System.in);
		Scanner manager = new Scanner(System.in);

		ArrayList<employee> emp = new ArrayList<employee>();
		while (true){
			System.out.println("1)worker\n\n2)manager");
			int se = sc.nextInt();
			if (se == 1)
			{
				System.out.println("1) sign in : \n\n2) log in : ");
				int b = sc.nextInt();
				if (b == 1){
					System.out.println("your name : ");
					String name = s.nextLine();

					System.out.println("family name : ");
					String family = s.nextLine();

					System.out.println("age : ");
					String age = s.nextLine();

					System.out.println("sabeqe kari : ");
					String sabeqe_kari = s.nextLine();

					System.out.println("enterd year to this company : ");
					String enterd_year = s.nextLine();

					System.out.println("mobile_phone : ");
					String mobile_phone = s.nextLine();

					System.out.println("username : ");
					username = s.nextLine();

					System.out.println("password : ");
					password = s.nextLine();

					emp.add(new employee(username , password, name ,family , age ,sabeqe_kari ,enterd_year , mobile_phone));

					try {
						WriteFile writer = new WriteFile("src/file.txt" ,true);
						writer.WriteToFile("***********");
						writer.WriteToFile("name :  " + name);
						writer.WriteToFile("family :  " + family);
						writer.WriteToFile("age :  " + age);
						writer.WriteToFile("sabeqe kari :  " + sabeqe_kari);
						writer.WriteToFile("enterd year :  " + enterd_year);
						writer.WriteToFile("mobile phone :  " + mobile_phone);
						writer.WriteToFile("username :  " + username);
						writer.WriteToFile("password :  " + password);
						writer.WriteToFile("***********");
					}catch (IOException e){
						System.out.println(e.getMessage());
					}


					System.out.println("new account added \n\nnow you can check your account :)");

					}else if (b == 2)
					{
						System.out.println("username : ");
						username = s.nextLine();

						/*log in from file*/

						// it check the username password from the file but just because of not enough time i could not to resolve this problem

						/*File filef = new File("src/file.txt");
						PrintWriter output = new PrintWriter(new FileWriter(filef, true));
						Scanner input = new Scanner(filef);
						boolean found = false;
						while(input.hasNext() && !found)
						{
							if (input.next().equals(username))
							{
								if (input.next().equals(password)){
									System.out.println("Login successful !");
									found = true;
									break;
								}

							}
						}
						if(!found)
						{
							System.out.println("Login incorrect !");
						}*/


						/*end login*/

						for (int i = 0; i < emp.size(); i++)
						{
							if (emp.get(i).getUsername().matches(username))
							{
								if (emp.get(i).getX()==3)
								{
									System.out.println("your account blocked.....please tell your boss to free up your account :) ");
									try {
										WriteFile writer = new WriteFile("src/blocked.txt" ,true);
										writer.WriteToFile("***********");
										writer.WriteToFile("username :  " + username);
										writer.WriteToFile("***********");
									}catch (IOException e){
										System.out.println(e.getMessage());
									}
									exit(0);
								}else
								{
									System.out.println("username found now enter the password :");
									String pass = s.nextLine();

									System.out.println("pass is : " + pass);
									if (emp.get(i).getPassword().matches(pass))
									{
										System.out.println("wellcome " + emp.get(i).getUsername() + " log in successfully");
										while(true)
										{
											System.out.println("1)morakhsi\n" + "2)reserve\n" + "3)see the food you reserve\n" + "4)exit");
											Scanner m = new Scanner(System.in);
											String chose = m.nextLine();
											if(chose.equals("1"))
											{
												mo.dMorakhsi();
											}else if(chose.equals("2"))
											{
												System.out.println("enter your food plz :");
												String food_worker = s.nextLine();
												try {
													WriteFile writer = new WriteFile("src/food_workers.txt" ,true);
													writer.WriteToFile("***********");
													writer.WriteToFile("username :  " + username);
													writer.WriteToFile("food :  " + food_worker);
													writer.WriteToFile("***********");
												}catch (IOException e){
													System.out.println(e.getMessage());
												}
												System.out.println("your food save in our System");

											}else if(chose.equals("3"))
											{
												try
												{
													File file = new File("src/food_workers.txt");
													Scanner scanfoodWorker = new Scanner(file);

													while (scanfoodWorker.hasNextLine())
													{
														System.out.println(scanfoodWorker.nextLine());
													}
												}catch (IOException e){
													System.out.println(e.getMessage());
												}

											} else if(chose.equals("4"))
											{
												break;
											}
										}
										Date a = new Date();
										long da = (a.getTime()-d.getTime())/1000;
										System.out.println("time that you were in this system is : "+da);
										break;
									} else
									{
										System.out.println("the wrong password!!");
										emp.get(i).setX(emp.get(i).getX()+1);
										System.out.println("you can try for : "+(3-emp.get(i).getX())+" times");
									}
								}
							}
						}
					}

				}else if (se == 2)
				{
					System.out.println("1)see accounts : \n\n2)free block accounts : \n\n3)food reservation : ");
					int see = manager.nextInt();
					if (see == 1)
					{
						try
						{
							File file = new File("src/file.txt");
							Scanner scanf = new Scanner(file);

							while (scanf.hasNextLine())
							{
								System.out.println(scanf.nextLine());
							}
						}catch (IOException e){
							System.out.println(e.getMessage());
						}
					}else if (see == 2)
					{
						try
						{
							File file = new File("src/blocked.txt");
							Scanner scanf = new Scanner(file);

							while (scanf.hasNextLine())
							{
								System.out.println(scanf.nextLine());
							}
						}catch (IOException e){
							System.out.println(e.getMessage());
						}

						System.out.println("there are list of blocked account----plz enter its username to free up its account\n");
						String free = s.nextLine();

						/*free block account*/

						File fileBlock = new File("src/blocked.txt");
						PrintWriter output = new PrintWriter(new FileWriter(fileBlock, true));
						Scanner input = new Scanner(fileBlock);
						boolean found = false;
						while(input.hasNext() && !found)
						{
							if (input.next().equals(free))
							{
								System.out.println("your account by username " +free+ " freed");
								found = true;
								break;
							}
						}
						if(!found)
						{
							System.out.println("this username not found in black lists");
						}

						/*end of free block account*/

					}else if (see == 3)
					{
						System.out.println("plz type your food");
						String food = s.nextLine();
						try {
							WriteFile writer = new WriteFile("src/food_manager.txt" ,true);
							writer.WriteToFile("***********");
							writer.WriteToFile("food :  " + food);
							writer.WriteToFile("***********");
						}catch (IOException e){
							System.out.println(e.getMessage());
						}
						System.out.println("your food register to our System bro :)");

					}
				}


		}
	}

}