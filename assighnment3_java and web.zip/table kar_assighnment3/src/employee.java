public class employee {

	private String username;
	private String password;
	private String name;
	private String family;
	private String age;
	private String sabeqe_kari;
	private String enterd_year;
	private String mobile_phone;
	private int x=0;

	public employee(String username , String password  ,String name ,String family , String age ,String sabeqe_kari ,String enterd_year ,String mobile_phone ) {
		super();
		this.setUsername(username);
		this.password = password;
		this.setName(name);
		this.setFamily(family);
		this.setAge(age);
		this.setSabeqe_kari(sabeqe_kari);
		this.setEnterd_year(enterd_year);
		this.setMobile_phone(mobile_phone);

	}
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSabeqe_kari() {
		return sabeqe_kari;
	}

	public void setSabeqe_kari(String sabeqe_kari) {
		this.sabeqe_kari = sabeqe_kari;
	}

	public String getEnterd_year() {
		return enterd_year;
	}

	public void setEnterd_year(String enterd_year) {
		this.enterd_year = enterd_year;
	}

	public String getMobile_phone() {
		return mobile_phone;
	}

	public void setMobile_phone(String mobile_phone) {
		this.mobile_phone = mobile_phone;
	}
}
